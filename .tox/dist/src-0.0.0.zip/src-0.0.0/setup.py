from setuptools import setup, find_packages

setup(
    name = "src",
    version="0.0.0",
    description="Wine package demo",
    author="Smekala",
    packages=find_packages(),
    license="MIT"
)